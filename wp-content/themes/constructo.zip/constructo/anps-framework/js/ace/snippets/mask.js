ace.define("ace/snippets/mask",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="mask"});                (function() {
                    ace.require(["ace/snippets/mask"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            