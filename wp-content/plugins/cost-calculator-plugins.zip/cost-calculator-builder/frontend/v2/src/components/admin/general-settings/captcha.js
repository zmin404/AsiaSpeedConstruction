import generalSettingsMixin from "./generalSettingsMixin";
export default {
	mixins: [generalSettingsMixin],
}