import settingsMixin from './settingsMixin';

export default {
	mixins: [settingsMixin],
	data: () => ({}),
	mounted() {},
}