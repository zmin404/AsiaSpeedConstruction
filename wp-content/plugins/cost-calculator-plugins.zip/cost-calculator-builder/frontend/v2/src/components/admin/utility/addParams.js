export const addParams = (key, value) => {
	key = encodeURIComponent(key);
	value = encodeURIComponent(value);

	// kvp looks like ['key1=value1', 'key2=value2', ...]
	let kvp = document.location.search.substr(1).split('&');
	let i = 0;

	for(; i < kvp.length; i++){
		if (kvp[i].startsWith(key + '=')) {
			let pair = kvp[i].split('=');
			pair[1] = value;
			kvp[i] = pair.join('=');
			break;
		}
	}

	if (i >= kvp.length) {
		kvp[kvp.length] = [key,value].join('=');
	}

	// can return this or...
	let params = kvp.join('&');

	// reload page with new params
	const newUrl = new URL(window.location.protocol + "//" + window.location.host + window.location.pathname + `?${params}`);
	newUrl.searchParams.set(key, value);
	window.history.pushState({ path: newUrl.href }, '', newUrl.href);
}

export const removeParams = (key) => {
	key = encodeURIComponent(key);
	const newUrl = new URL(window.location.protocol + "//" + window.location.host + window.location.pathname + `${window.location.search}`);
	newUrl.searchParams.delete(key);
	window.history.pushState({ path: newUrl.href }, '', newUrl.href);
}