export default [
	{alias: 'Live', value: 'live'},
	{alias: 'Sandbox', value: 'sandbox'}
];