<?php

namespace cBuilder\Classes;

class CCBProAjaxCallbacks {

}